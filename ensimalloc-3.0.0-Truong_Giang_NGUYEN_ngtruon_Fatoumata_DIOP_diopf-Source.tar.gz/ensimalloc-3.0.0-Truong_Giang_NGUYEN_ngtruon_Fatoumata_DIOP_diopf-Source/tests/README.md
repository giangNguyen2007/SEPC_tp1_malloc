Tests unitaires
==========

Ces tests sont réalisés en utilisant la bibliothèque libgtest (Google
test unit).

